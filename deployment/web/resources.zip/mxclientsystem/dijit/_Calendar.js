//>>built
define("dijit/_Calendar",["dojo/_base/kernel","./Calendar","./main"],function(_1,_2,_3){
_1.deprecated("dijit._Calendar is deprecated","dijit._Calendar moved to dijit.Calendar",2);
_3._Calendar=_2;
});
