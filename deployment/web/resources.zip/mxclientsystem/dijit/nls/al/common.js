//>>built
define("dijit/nls/al/common",{buttonOk:"OK",buttonCancel:"Anullo",buttonSave:"Ruaj",itemClose:"Mbyll"});
